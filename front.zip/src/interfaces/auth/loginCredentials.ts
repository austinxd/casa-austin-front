export interface ILogin {
    password: string
    email: string
}
