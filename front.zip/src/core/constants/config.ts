export const ENV = {
    API_URL: 'https://api.casaaustin.pe/api/v1',
}
