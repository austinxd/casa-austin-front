const filterTextHouse2 = (e: string): string => {
    switch (e) {
        case 'CA1':
            return 'Casa Austin (waze, maps, uber, etc)'
        case 'CA2':
            return 'Casa Austin (waze, maps, uber, etc)'
        case 'CA3':
            return 'Casa Austin (waze, maps, uber, etc)'
        case 'CA4':
            return 'Casa Austin (waze, maps, uber, etc)'

        default:
            return 'Casa Austin (waze, maps, uber, etc'
    }
}

export default filterTextHouse2
