const filterTextHouse2 = (e: string): string => {
    switch (e) {
        case 'Casa Austin 1':
            return 'Casa Austin 1'
        case 'Casa Austin 2':
            return 'Casa Austin 2'
        case 'Casa Austin 3':
            return 'Casa Austin 3'
        case 'Casa Austin 4':
            return 'Casa Austin 4'

        default:
            return 'Casa Austin'
    }
}

export default filterTextHouse2
